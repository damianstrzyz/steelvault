import { createContext, useContext } from "react";

export type ToastVariant = "success" | "error" | "info";
export interface ToastApi { show: (message: string, variant?: ToastVariant) => void }

export const ToastContext = createContext<ToastApi | null>(null);

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}
